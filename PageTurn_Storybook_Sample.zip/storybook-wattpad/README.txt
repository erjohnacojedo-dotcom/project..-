PageTurn Storybook Library sample

Open index.html in a browser. No build tools required.
Files: index.html (semantic HTML), styles.css (external CSS), books.js (30 original sample stories), script.js (external JavaScript), images/ (local SVG cover and story illustrations).
Features: responsive grid, 30 genres/story entries, one chapter per story, working navigation, read-story dialog, genre/search filters, favorites stored in localStorage, dark/light mode, reading progress display.

Note: All stories and author names are fictional sample content.
